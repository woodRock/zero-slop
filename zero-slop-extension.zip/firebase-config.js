const firebaseConfig = {
  apiKey: "AIzaSyDDx5ZbgWcgsKxsP78EubqyWRHL9yxdXec",
  authDomain: "zero-slop.firebaseapp.com",
  projectId: "zero-slop",
  storageBucket: "zero-slop.firebasestorage.app",
  messagingSenderId: "698330821807",
  appId: "1:698330821807:web:1900f5850bd6ab0f6e905a",
  measurementId: "G-PH6NYBGCKG"
};

export default firebaseConfig;
